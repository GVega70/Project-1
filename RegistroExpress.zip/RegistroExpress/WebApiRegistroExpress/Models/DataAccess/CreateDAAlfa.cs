﻿namespace WebApiRegistroExpress.Models.DataAccess
{
    public class CreateDAAlfa
    {
        public string Id_prog { get; set; }
        public string Id_carrer { get; set; }

    }
}
