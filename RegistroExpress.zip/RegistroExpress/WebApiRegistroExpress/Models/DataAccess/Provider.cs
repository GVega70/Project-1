﻿namespace WebApiRegistroExpress.Models.DataAccess
{
    public class Provider
    {
    }
}