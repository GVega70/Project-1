﻿using Oracle.ManagedDataAccess.Client;

namespace WebApiRegistroExpress.Models.DataAccess
{
    public class DAAlfa
    {
        public string Id_prog  { get; set; }
        public string Id_carrer { get; set; }

    }

    public List<Provider> GetProviders()
    {
        List<Provider> model = null;
        OracleConnection connection = null;
        string query = @"SELECT * FROM PS_UAG_REGEXP_TBL";

        try
        {
            using(connection = new OracleConnection(BDAyuda.ObtenerCadenadeConexion(_appSettings.Conexion_RegistroExpress)))
            {
                using (OracleCommand cmd = new OracleCommand(query,connection))
                {
                    connection.Open();
                    using (OracleDataReader reader = cmd.ExecuteReader())
                    {
                        if (lector.HasRows)
                        {
                            model = new List<Provider>()
                            while (lector.Read())
                            {
                                Provider auxModel = new Provider();
                                auxModel.LmsProvider = lector["CONEXION_REGISTRO_EXPRESS"].ToString();

                            }

                    }
                    }
                }
            }
        }


    }
}
