﻿namespace WebApiRegistroExpress.Models.BusinessLogic
{
    public class BLHome
    {
    }
}
