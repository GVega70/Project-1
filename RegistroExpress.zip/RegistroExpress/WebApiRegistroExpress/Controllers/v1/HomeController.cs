﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApiRegistroExpress.Models.DataAccess;

namespace WebApiRegistroExpress.Controllers.v1
{
    [ApiController]
    [Route("[controller]")]
    
    public class HomeController : Controller
    {
        private readonly IHttpContextAccessor _httpClientFactory;
        private readonly AppSettings _appSettings;
        private readonly BLAlfa _bl;

        ///api/programas}
        [HttpGet]
        public List<DAAlfa> GetProgramas()
        {
            throw new NotImplementedException();
        }

        //api/programas/{id_prog}
        [HttpGet("{id_prog}")]
        public DAAlfa GetPrograma(string id_prog)
        {
            throw new NotImplementedException();
        }

        [HttpDelete("{id_prog}")]
        public Task<bool> DeletePrograma(string id_prog)
        {
            throw new NotImplementedException();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public DAAlfa CreatePrograma(CreateDAAlfa programa)
        {
            throw new NotImplementedException();
        }

        [HttpPut]
        public DAAlfa UpdatePrograma(DAAlfa programa)
        {
            throw new NotImplementedException();
        }

        // GET: HomeController
        public ActionResult Index()
        {
            return View();
        }

        // GET: HomeController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: HomeController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: HomeController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: HomeController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: HomeController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: HomeController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: HomeController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        public IEnumerable<HomeController> Get()
        {
            return Enumerable.Range(1, 5).Select(index => new HomeController
            {
                Date = DateTime.Now.AddDays(index),
                TemperatureC = Random.Shared.Next(-20, 55)
                //Summary = Summaries[Random.Shared.Next(Summaries)]
            })
            .ToArray();
        }
    }
}
