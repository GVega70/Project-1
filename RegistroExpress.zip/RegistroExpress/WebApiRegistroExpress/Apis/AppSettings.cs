﻿namespace WebApiRegistroExpress.Apis
{
    internal class AppSettings
    {
        _appSettings = appSettings;
        _UAG_API = _appSettings.UAG_API_Seguridad;
        _UAG_API_Usuario = _appSettings.UAG_API_Seguridad_User;
        _UAG_API_Pass = appSettings.UAG_API_Pass;
    }
}