﻿namespace WRegistroExpress.Models.DataAccess
{
    public class bdAlfa
    {
    }
}
