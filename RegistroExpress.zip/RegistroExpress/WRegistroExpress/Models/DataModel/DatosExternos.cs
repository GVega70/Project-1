﻿namespace WRegistroExpress.Models.DataModel
{
    public class DatosExternos
    {
        
        string nomalu { get; set; }
        string appaterno { get; set; }
        string apmaterno { get; set; }
        string fecnac { get; set; }
        string sexoalu { get; set; }
        string estadocivil { get; set; }
        string correoppalalu { get; set; }
        string tipcorreoalu { get; set; }
        string numtel { get; set; }
        string tipotel { get; set; }
        string telfavorito { get; set; }
        string direccionalu { get; set; }
        string cruzacon { get; set; }
        string paisalu { get; set; }
        string coloniaalu { get; set; }
        string ciudadalu { get; set; }
        string estadoalu { get; set; }
        string codigopostalalu { get; set; }
        string nacalu { get; set; }
        string paisnacalu { get; set; }
        string edonacalu { get; set; }
        string cdnacalu { get; set; }
        string lenguaind { get; set; }
        string cuallengind { get; set; }
        string admisiontipo { get; set; }
        string refe { get; set; }
        string religionalu { get; set; }
        string paisescproc { get; set; }
        string edoescproc { get; set; }
        string cdescproc { get; set; }
        string escprocede { get; set; }
        string nivacainsc { get; set; }
        string carrainsc { get; set; }
        string perainsc { get; set; }
        string strmalu { get; set; }
        string campusalu { get; set; }
        string gradoalu { get; set; }
        string curpalu { get; set; }
        string idEscCS { get; set; }
        string idsolcs { get; set; }
        string tipoinc { get; set; }
        string idestcs { get; set; }
        string stadesc { get; set; }
        string neealu { get; set; }
    

    }
}
