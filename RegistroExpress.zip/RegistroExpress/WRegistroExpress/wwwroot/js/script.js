function leerArchivo2(evt) {
    let reader = new FileReader();
    reader.onload = (evt) => {
        // Cuando el archivo se termin� de cargar
        crearTabla(evt.target.result)
    };
    // Leemos el contenido del archivo seleccionado
    reader.readAsText(evt);
}

// document.querySelector('#archivo2').addEventListener('change', leerArchivo2, false);



function pasarRuta() {

    /* Pasar la ruta del archivo a el input text nombre de archivo */
    const archivoInput = document.getElementById('archivo2');
    const rutaTexto = document.getElementById('archivo2');
    const archivoSeleccionado = archivoInput.files[0];

    if (archivoSeleccionado) {
        const rutaArchivo = URL.createObjectURL(archivoSeleccionado);
        nombreArchivo.value = rutaArchivo;
    } else {
        nombreArchivo.value = "";
    }
    /* Validar que el archivo que se haya seleccionado es .csv */
    var extension = archivoSeleccionado.name.split('.').pop().toLowerCase();

    if (extension !== 'csv') {
        alert('Por favor selecciona un archivo CSV.');
        return false;
    }
    else {
        leerArchivo2(archivoSeleccionado);
    }
    return true;

}
    /*CREAR TABLA PARA MOSTRAR INFORMACION */

function crearTabla(data) {
    console.log("Archivo seleccionado");
    const todasFilas = data.split(/\r?\n|\r/);
    let tabla = '<table style="width: 100%;">';
    let lista = '<ul>';

    for (let fila = 0; fila < todasFilas.length; fila++) {
        if (fila === 0) {
            tabla += '<thead>';
            tabla += '<tr>';
        } else {
            tabla += '<tr>';
        }

        const celdasFila = todasFilas[fila].split(',');

        for (let rowCell = 0; rowCell < celdasFila.length; rowCell++) {
            if (fila === 0) {
                tabla += '<th class="grid-cell">';
                tabla += celdasFila[rowCell];
                tabla += '</th>';
            } else {
                tabla += '<td class="grid-cell">';
                if (rowCell === 4) {
                //    tabla += "<img src=\"img/" + celdasFila[rowCell] + "\">";
                    tabla += celdasFila[rowCell];
                } else {
                    tabla += celdasFila[rowCell];
                }
                tabla += '</td>';
            }

            if (fila > 0) {
                lista += '<li>' + celdasFila[rowCell] + '</li>';
            }
        }

        if (fila === 0) {
            tabla += '</tr>';
            tabla += '</thead>';
            tabla += '<tbody>';
        } else {
            tabla += '</tr>';
        }
    }

    tabla += '</tbody>';
    tabla += '</table>';
    lista += '</ul>';

    document.querySelector('#tablares').innerHTML = tabla;
    document.querySelector('#listares').innerHTML = lista;
    //validaDatosExternos();
}

// Se lee la lista y se valida que la informaci�n sea la correcta
/*function validaDatosExternos() {
    const listaItems = document.querySelectorAll('#listares li');
    const carrera1 = "EDUC";
    const carrera2 = "INT";
    const carrera3 = "EME";
    const carrera4 = "LIS"
    const programa1 = "LME21";
    const programa2 = "LMR21";
    var contador = 0;
    var datosValidos = true;

    listaItems.forEach((item, index) => {  // Agregamos un �ndice para saber el n�mero de elemento
        const texto = item.innerText;
        contador = contador + 1;

        if (contador === 32) {
            if (texto === carrera1 || texto === carrera2 || texto === carrera3) {
                console.log(`La carrera si est� dentro de las autorizadas': ${texto}`);
            } else {
                console.log(`La carrera no est� dentro de las autorizadas: ${texto}`);
                datosValidos = false;
            }
        }

        if (contador === 31) {
            if (texto === programa1 || texto === programa2) {
                console.log(`El programa si est� dentro de las autorizadas': ${texto}`);
            } else {
                console.log(`El programa no est� dentro de las autorizadas: ${texto}`);
                datosValidos = false;
            }
        }

        if (datosValidos === true {
            llamarApiPing();
        }

      
    });
}



function llamarApiPing() {

}*/



