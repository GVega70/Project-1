﻿namespace WRegistroExpress.BusinessLogic
{
    public class BLRegistroAlumnos
    {

        public void ValidaDatosExternos(List<string> listaItems)
        {
            Console.WriteLine("Se ha llegado a la función ValidaDatosExternos");
            string carrera1 = "EDUC";
            string carrera2 = "INT";
            string carrera3 = "EME";
            string carrera4 = "LIS";
            string programa1 = "LME21";
            string programa2 = "LMR21";
            bool datosValidos = true;

            for (int i = 0; i < listaItems.Count; i++)
            {
                string texto = listaItems[i];
                int contador = i + 1;

                if (contador == 32)
                {
                    if (texto == carrera1 || texto == carrera2 || texto == carrera3 || texto == carrera4)
                    {
                        Console.WriteLine($"La carrera si está dentro de las autorizadas: {texto}");
                    }
                    else
                    {
                        Console.WriteLine($"La carrera no está dentro de las autorizadas: {texto}");
                        datosValidos = false;
                    }
                }

                if (contador == 31)
                {
                    if (texto == programa1 || texto == programa2)
                    {
                        Console.WriteLine($"El programa si está dentro de las autorizadas: {texto}");
                    }
                    else
                    {
                        Console.WriteLine($"El programa no está dentro de las autorizadas: {texto}");
                        datosValidos = false;
                    }
                }
            }

            if (datosValidos)
            {
                LlamarApiPing();
            }
        }

        public void LlamarApiPing()
        {
            // Código para llamar a la API
        }
    }
}
